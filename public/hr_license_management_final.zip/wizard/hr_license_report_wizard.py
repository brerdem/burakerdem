from odoo import models, fields, api
import base64
import io
import xlsxwriter

class HrLicenseReport(models.TransientModel):
    _name = "hr.license.report.wizard"
    _description = "License Cost Report Wizard"

    period = fields.Selection([
        ("monthly", "Monthly"),
        ("yearly", "Yearly")
    ], string="Period", required=True, default="monthly")

    file_download = fields.Binary("Download File")
    file_name = fields.Char("File Name")

    def _compute_cost(self, license):
        if license.subscription_type == "monthly":
            return license.cost
        elif license.subscription_type == "yearly":
            return license.cost / 12 if self.period == "monthly" else license.cost
        return license.cost if self.period == "yearly" else license.cost

    def get_report_data(self):
        employees = self.env["hr.employee"].search([])
        data = []
        for emp in employees:
            total_cost = sum(self._compute_cost(lic) for lic in emp.license_ids)
            data.append({
                "employee": emp.name,
                "department": emp.department_id.name or "No Department",
                "cost": total_cost
            })
        return data

    def action_generate_excel(self):
        data = self.get_report_data()
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {"in_memory": True})
        sheet = workbook.add_worksheet("License Report")

        headers = ["Employee", "Department", "Cost"]
        for col, header in enumerate(headers):
            sheet.write(0, col, header)

        total_cost = 0
        for row, rec in enumerate(data, start=1):
            sheet.write(row, 0, rec["employee"])
            sheet.write(row, 1, rec["department"])
            sheet.write(row, 2, rec["cost"])
            total_cost += rec["cost"]

        sheet.write(len(data)+1, 1, "Total Cost")
        sheet.write(len(data)+1, 2, total_cost)

        workbook.close()
        output.seek(0)
        self.file_download = base64.b64encode(output.read())
        self.file_name = "license_report.xlsx"
        return {
            "type": "ir.actions.act_url",
            "url": f"/web/content/?model={self._name}&id={self.id}&field=file_download&download=true&filename={self.file_name}",
            "target": "self",
        }
