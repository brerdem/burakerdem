{
    "name": "HR License Management",
    "version": "1.3",
    "depends": ["hr"],
    "author": "Custom",
    "category": "Human Resources",
    "description": "Manage software licenses and assign them to employees, with cost reports and Excel export.",
    "data": [
        "views/hr_license_views.xml",
        "views/hr_license_report_views.xml",
        "views/hr_employee_views.xml"
    ],
    "installable": True
}
