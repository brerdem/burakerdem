from odoo import models, fields, api


class HrLicenseReportWizard(models.TransientModel):
    _name = "hr.license.report.wizard"
    _description = "HR License Report Wizard"

    period = fields.Selection(
        [
            ("current_month", "Current Month"),
            ("current_quarter", "Current Quarter"),
            ("current_year", "Current Year"),
        ],
        string="Period",
        required=True,
        default="current_month"
    )

    def action_generate_excel(self):
        """Generate Excel report for license data"""
        # Basic implementation - you can enhance this later
        licenses = self.env['hr.license'].search([])
        
        # For now, just return a simple action - you can implement Excel generation later
        return {
            'type': 'ir.actions.act_window',
            'name': 'License Report Generated',
            'res_model': 'hr.license',
            'view_mode': 'list',
            'domain': [],
            'context': {'period': self.period}
        }
