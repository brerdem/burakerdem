{
    "name": "HR License Management",
    "version": "2.0",
    "depends": ["hr"],
    "author": "Custom",
    "category": "Human Resources",
    "data": [
        "security/ir.model.access.csv",
        "views/hr_license_views.xml",
        "views/hr_license_report_views.xml",
        "views/hr_employee_views.xml"
    ],
    "installable": True,
    "application": True
}
