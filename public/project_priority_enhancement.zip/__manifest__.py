{
    'name': 'Project Priority Enhancement',
    'version': '1.0.0',
    'summary': 'Enhanced 3-Star Priority System for Project Tasks',
    'description': """
        This module enhances project task priorities with a 3-level system:
        - Low Priority
        - High Priority  
        - Critical Priority
        
        Features:
        - Custom priority field with 3 levels
        - Enhanced Kanban card display
        - Priority-based sorting and filtering
    """,
    'author': 'Custom Development',
    'website': '',
    'category': 'Project',
    'depends': ['project'],
    'data': [
        'security/ir.model.access.csv',
        'views/project_task_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}