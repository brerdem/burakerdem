from odoo import models, fields, api


class ProjectTask(models.Model):
    _inherit = 'project.task'

    priority = fields.Selection([
        ('0', 'None'),
        ('1', 'Medium'),
        ('2', 'High'), 
        ('3', 'Very High')
    ], string='Priority', default='0', index=True)