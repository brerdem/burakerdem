# Project Priority Enhancement

## Overview

This module enhances the Project Task priority system with a 3-level priority display in Kanban cards.

## Features

### Priority Levels

- **Low Priority** (★☆☆) - Green color
- **High Priority** (★★☆) - Orange color
- **Critical Priority** (★★★) - Red color

### Enhancements

- ✅ Visual priority stars in Kanban cards
- ✅ Color-coded priority indicators
- ✅ Enhanced priority widget in forms/lists
- ✅ Priority-based filtering and grouping
- ✅ Border indicators on Kanban cards

## Installation

1. Copy this module to your Odoo addons directory
2. Update Apps List
3. Install "Project Priority Enhancement"

## Usage

1. Go to Project → Tasks
2. Open any task
3. Set the priority using the new 3-level system
4. View enhanced Kanban cards with star indicators

## Dependencies

- project (base Project module)

## Compatibility

- Odoo 15.0+
- Compatible with existing project workflows
