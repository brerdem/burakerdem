from odoo import models, fields
# Placeholder wizard code
