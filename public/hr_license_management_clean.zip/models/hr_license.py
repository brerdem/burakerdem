from odoo import models, fields

class HrLicense(models.Model):
    _name = "hr.license"
    _description = "Software License"

    name = fields.Char(string="License Name", required=True)
    cost = fields.Float(string="Cost")
    subscription_type = fields.Selection(
        [
            ("one_time", "One Time"),
            ("monthly", "Monthly"),
            ("yearly", "Yearly"),
        ],
        string="Subscription Type",
        required=True,
    )
    employee_ids = fields.Many2many("hr.employee", string="Assigned Employees")

class HrEmployee(models.Model):
    _inherit = "hr.employee"

    license_ids = fields.Many2many("hr.license", string="Licenses")
